This a very preliminary, pre-alpha, Stage 0 release of the Base Technology Agent Server software.

It is not yet suitable for production use and is intended for preliminary evaluation only.

See LICENSE.txt for software licensing terms. Basically, it is the Apache ASL 2.0.

See NOTICES.txt for licensing of software that is included with this software.

Full source code can be found on GitHub at https://github.com/jack-krupansky-BT/Agent-Server-Stage-0

For more information contact Jack Krupansky at Jack@BaseTechnology.com
